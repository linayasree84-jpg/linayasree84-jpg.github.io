Linaya Kandhasree Portfolio

This is a static portfolio website. Open index.html in a browser to preview it.

To publish with GitHub Pages:
1. Create a public repository named linayasree84-jpg.github.io
2. Upload index.html to the repository root.
3. Open Settings > Pages.
4. Choose Deploy from a branch, select main and /(root), then Save.
5. After deployment, visit https://linayasree84-jpg.github.io

Please verify all profile details and links before sharing.
